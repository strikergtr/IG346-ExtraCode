using Fusion;
using UnityEngine;

public class Switch : NetworkBehaviour
{
    public Color onColor;
    public Color offColor;
    [Networked]
    public bool isOn { get; set; }
    public SpriteRenderer spriteRenderer;

    public bool spawn = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Update()
    {
        if (!spawn) return;
        if (isOn)
        {
            spriteRenderer.color = onColor;
            GameManager.Instance.door_switchOn = true;
        }
        else
        {
            spriteRenderer.color = offColor;
            GameManager.Instance.door_switchOn = false;
        }
    }

    public override void Spawned()
    {
        spawn = true;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        print("E");
        if (collision.gameObject.tag == "Player")
        {
            if (!HasStateAuthority) return;
            isOn = !isOn;
        }
    }
}